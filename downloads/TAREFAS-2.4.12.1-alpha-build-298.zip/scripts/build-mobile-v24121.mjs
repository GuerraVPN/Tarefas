import { readFile, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';

const root=process.cwd(), dist=path.join(root,'dist');
const VERSION='2.4.12.1', BUILD=298, PATCH='2.4.9.11';

const patch=async(file,fn)=>{
  const p=path.join(dist,file);
  const before=await readFile(p,'utf8');
  const after=fn(before);
  if(after!==before) await writeFile(p,after,'utf8');
};

// Reusa exatamente a cadeia validada da Beta 2.4.9 (build 293).
await import('./build-mobile-v249.mjs');

const patchPath=path.join(root,'patches/TAREFAS-2.4.9.11.tpatch');
const p=JSON.parse(await readFile(patchPath,'utf8'));
if(p.id!==PATCH || p.baseVersion!=='2.4.9.7' || Number(p.minBuild)!==293 || Number(p.maxBuild)!==294){
  throw new Error('2.4.12: patch 2.4.9.11 incompatível com a Beta 2.4.9.');
}
const payloadText=JSON.stringify({js:String(p.payload?.js||''),css:String(p.payload?.css||'')});
const actual=createHash('sha256').update(payloadText,'utf8').digest('hex');
if(actual!==String(p.payloadSha256||'').toLowerCase()){
  throw new Error('2.4.12: SHA interno do 2.4.9.11 divergente: '+actual);
}

// Injeta somente o patch 2.4.9.11 no bundle da 2.4.9.
await patch('mobile-bootstrap.js',source=>{
  const marker='__TAREFAS_ALPHA_24911_CONSOLIDATED__';
  if(source.includes(marker)) return source;
  return source+"\n;(()=>{'use strict';if(globalThis['"+marker+"'])return;globalThis['"+marker+"']=true;"+
    "const s=document.createElement('style');s.id='tarefas-24911-consolidated-style';s.textContent="+JSON.stringify(String(p.payload?.css||''))+";document.head.appendChild(s);"+
    String(p.payload?.js||'')+"\n})();\n";
});

// Promove somente os identificadores da versão/build; não injeta nenhuma correção de layout da 2.4.11.
for(const file of ['mobile-bootstrap.js','mobile-login-v17.js','index.html','mobile-patch-manager-v240.js','mobile-release-v240.js','mobile-v12.js','package.json','v7_5_1_about.js']){
  await patch(file,s=>s
    .replaceAll('2.4.9.7',VERSION)
    .replaceAll('2.4.9',VERSION)
    .replaceAll('APP_BUILD=293','APP_BUILD='+BUILD)
    .replaceAll('APP_BUILD = 293','APP_BUILD = '+BUILD)
    .replaceAll('build:293','build:'+BUILD)
    .replaceAll('build: 293','build: '+BUILD)
    .replaceAll("APP_CHANNEL='alpha'","APP_CHANNEL='alpha'")
    .replaceAll("APP_CHANNEL = 'alpha'","APP_CHANNEL = 'alpha'")
    .replaceAll("channel:'alpha'","channel:'alpha'")
    .replaceAll("channel: 'alpha'","channel: 'alpha'")
  );
}

await rm(path.join(dist,'BETA_2_4_9.json'),{force:true});
await rm(path.join(dist,'BETA_2_4_10.json'),{force:true});
await rm(path.join(dist,'BETA_2_4_11.json'),{force:true});
await rm(path.join(dist,'ALPHA_2_4_9_7.json'),{force:true});
await writeFile(path.join(dist,'ALPHA_2_4_12_1.json'),JSON.stringify({
  version:VERSION,build:BUILD,channel:'alpha',
  base:'2.4.9',basedOn:'2.4.9',
  incorporatedPatch:PATCH,
  features:{
    notesFiscalPatch24911:true,
    patchManagerPreserved:true,patchManagerV1:true,
    scalesPreserved:true,servicesHotbar2468:true,
    dashboardNextServiceRemoved:true,web797Preserved:true,
    appOnly:true,webDecoupled:true,webVersionVisible:false,
    webDependency:false,releaseBranchIsolatedFromMain:true
  }
},null,2)+'\n');


// 2.4.12.1: o Android não expõe mais a identificação/base da Web.
await patch('mobile-bootstrap.js',source=>source
  .replace("const WEB_VERSION = '7.9.7';", "const WEB_VERSION = '';")
  .replace('<article><small>Base web</small><strong>${WEB_VERSION}</strong></article>\\n        ','')
);

const boot=await readFile(path.join(dist,'mobile-bootstrap.js'),'utf8');
const pm=await readFile(path.join(dist,'mobile-patch-manager-v240.js'),'utf8');

// A base 2.4.9 navigation sanity check: preserve the original drawer and bottom navigation.
for(const marker of ['tmDrawer','tm-bottom-nav','__TAREFAS_ALPHA_2468_SERVICOS_HOTBAR_FIX__','__TAREFAS_PATCH_CONSOLIDATED_2487__','__TAREFAS_ALPHA_2485_BIOMETRIC_SINGLE_PROMPT__','__TAREFAS_ALPHA_24911_CONSOLIDATED__']){
  if(!boot.includes(marker)) throw new Error('2.4.12: marcador/base ausente '+marker);
}
if(boot.includes('__TAREFAS_ANDROID_2411_BOTTOM_TABS_FIX__')){
  throw new Error('2.4.12: correção de layout da 2.4.11 foi incorporada indevidamente.');
}
if(!boot.includes("const APP_VERSION = '2.4.12.1';") || !boot.includes('const APP_BUILD = 298;')){
  throw new Error('2.4.12: versão/build incorretos.');
}
if(!pm.includes("2.4.12.1") || !pm.includes("298")){
  throw new Error('2.4.12.1: Patch Manager não promovido com versão/build.');
}
console.log('TAREFAS Android 2.4.12.1 build 298 — Alpha 2.4.9 + patch 2.4.9.11 OK.');

// Alpha 2.4.12.1 build trigger.

// validation fix trigger.

// pm validation trigger.
